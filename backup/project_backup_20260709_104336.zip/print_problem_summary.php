<?php
date_default_timezone_set('Asia/Dhaka');
include 'auth_check.php';
include 'db.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$group_filter = isset($_GET['group_no']) ? trim($_GET['group_no']) : '';
$problem_filter = isset($_GET['problem']) ? trim($_GET['problem']) : '';

$sql = "SELECT problem, COUNT(*) AS total_count
        FROM atm_update
        WHERE incident_status = 'Open'";

$params = [];
$types = "";

if ($search !== '') {
    $sql .= " AND (
        atm_id LIKE ? OR
        atm_name LIKE ? OR
        atm_vendor LIKE ? OR
        ups_vendor LIKE ? OR
        problem LIKE ?
    )";
    $searchLike = "%" . $search . "%";
    $params = array_merge($params, [$searchLike,$searchLike,$searchLike,$searchLike,$searchLike]);
    $types .= "sssss";
}

if ($group_filter !== '') {
    $sql .= " AND group_no = ?";
    $params[] = (int)$group_filter;
    $types .= "i";
}

if ($problem_filter !== '') {
    $sql .= " AND problem = ?";
    $params[] = $problem_filter;
    $types .= "s";
}

$sql .= " GROUP BY problem ORDER BY total_count DESC, problem ASC";

$stmt = $conn->prepare($sql);
if (!$stmt) die("Prepare failed: " . $conn->error);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$grandTotal = 0;
$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
    $grandTotal += (int)$row['total_count'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Problem Wise Summary</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 16px; color:#000; }
        .report-header { text-align:center; margin-bottom:8px; }
        .report-header h1, .report-header h2, .report-header p { margin:2px 0; }
        table { width:100%; border-collapse:collapse; font-size:13px; }
        th, td { border:1px solid #000; padding:6px 8px; text-align:left; }
        th { background:#f2f2f2; }
        .center { text-align:center; }
        .bold { font-weight:bold; }
        @media print {
            @page { margin: 10mm; }
            body { margin:0; }
        }
    </style>
</head>
<body>
<div class="report-header">
    <h1>Islami Bank Bangladesh PLC</h1>
    <h2>ATM Management Division, DBW</h2>
    <p>Problem Wise Summary as on <?php echo date('d-M-Y'); ?></p>
</div>

<div style="margin-bottom:8px;">
    <button onclick="window.print()">Print</button>
</div>

<table>
    <thead>
        <tr>
            <th class="center">S/L</th>
            <th>Problem</th>
            <th class="center">Total Open Incidents</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($rows) > 0) { ?>
            <?php foreach ($rows as $index => $row) { ?>
                <tr>
                    <td class="center"><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($row['problem']); ?></td>
                    <td class="center"><?php echo (int)$row['total_count']; ?></td>
                </tr>
            <?php } ?>
            <tr class="bold">
                <td colspan="2" class="center">Grand Total</td>
                <td class="center"><?php echo $grandTotal; ?></td>
            </tr>
        <?php } else { ?>
            <tr>
                <td colspan="3" class="center">No data found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</body>
</html>