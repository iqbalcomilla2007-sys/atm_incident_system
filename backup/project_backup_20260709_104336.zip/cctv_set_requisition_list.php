<?php
date_default_timezone_set('Asia/Dhaka');

include 'auth_check.php';
include 'db.php';
include 'includes/functions.php';

Auth::requirePermission('cctv_set_requisition');

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   BRANCH INSTALLATION MAIL FORMAT (সংশোধিত)
========================================================= */
if (isset($_GET['view_branch_mail']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // আপনার cctv_vendors টেবিল অনুযায়ী কলামের নাম mobile, email, contact_person ব্যবহার করা হয়েছে
    $stmt = $conn->prepare("
        SELECT 
            r.requisition_no, r.requisition_date,
            l.atm_id, l.booth_name, l.branch_name,
            v.vendor_name, v.mobile, v.email, v.contact_person
        FROM cctv_set_requisition r
        LEFT JOIN cctv_locations l ON r.cctv_location_id = l.id
        LEFT JOIN cctv_vendors v ON r.selected_vendor_id = v.id
        WHERE r.id = ? LIMIT 1
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if (!$data) die("Requisition record not found.");

    // আইটেম লিস্ট ফেচ করা
    $itemStmt = $conn->prepare("
        SELECT ri.qty, im.item_name 
        FROM cctv_set_requisition_items ri
        JOIN cctv_item_master im ON ri.item_id = im.id
        WHERE ri.requisition_id = ?
    ");
    $itemStmt->bind_param("i", $id);
    $itemStmt->execute();
    $items = $itemStmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Branch Installation Mail</title>
    <style>
    @page { size: A4; margin: 0; }
    body { margin: 0; font-family: "Times New Roman", serif; color: #000; background: #f4f7fa; }
    .page { width: 210mm; height: 297mm; box-sizing: border-box; padding: 11mm 14mm 8mm 14mm; margin: 20px auto; background: #fff; box-shadow: 0 0 10px rgba(0,0,0,0.1); display: flex; flex-direction: column; }
    .main-content { flex: 1; font-size: 13.5px; line-height: 1.4; }
    .letterhead { height: 65px; position: relative; margin-bottom: 15px; border-bottom: 2px solid #006837; }
    .left-logo { position: absolute; left: 0; top: 0; width: 60px; }
    .right-logo { position: absolute; right: 0; top: 3px; width: 225px; text-align: right; }
    .left-logo img, .right-logo img { max-width: 100%; height: auto; }
    .meta { display: flex; justify-content: space-between; margin-bottom: 15px; font-weight: bold; }
    .subject { font-weight: bold; text-decoration: underline; margin: 15px 0; }
    .data-table { width: 100%; border-collapse: collapse; margin: 10px 0; }
    .data-table th, .data-table td { border: 1px solid #333; padding: 6px 8px; font-size: 13px; }
    .data-table th { background: #f2f2f2; text-align: center; }
    .footer-box { text-align: center; font-size: 10px; border-top: 1px solid #777; padding-top: 5px; margin-top: auto; }
    .no-print { text-align: center; margin: 20px 0; }
    .btn-print { padding: 10px 20px; background: #198754; color: #fff; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; margin: 5px; }
    @media print { .no-print { display: none; } .page { margin: 0; box-shadow: none; } body { background: #fff; } }
    </style>
</head>
<body onload="window.print()">
<?php include_once __DIR__ . '/includes/navbar.php'; ?>
<div class="no-print">
    <button class="btn-print" onclick="window.print()">Print Letter</button>
    <button class="btn-print" style="background:#6c757d;" onclick="window.close()">Close</button>
</div>
<div class="page">
    <div class="main-content">
        <div class="letterhead">
            <div class="left-logo"><img src="assets/ibbl_mark.png"></div>
            <div class="right-logo"><img src="assets/ibbl_header_logo.png"></div>
        </div>
            
        <p class="subject">Subject: Permission for vendor access to install CCTV System at <?= h($data['booth_name']) ?> ATM Booth.</p>
        <p>Muhtaram,<br> Assalamu Alaikum,</p>
        <p>We would like to inform you that the following vendor has been assigned to install/replace CCTV equipment(s) at <strong><?= h($data['booth_name']) ?> (ATM ID: <?= h($data['atm_id']) ?>)</strong>:</p>
        <div style="background: #f9f9f9; padding: 10px; border: 1px dashed #999; margin: 10px 0;">
            <strong>Vendor Name:</strong> <?= h($data['vendor_name']) ?><br>
            <strong>Contact Person:</strong> <?= h($data['contact_person'] ?: '___________________________') ?><br>
            <strong>Mobile:</strong> <?= h($data['mobile'] ?: '___________________________') ?>
        </div>
        <p>In this connection, you are requested to allow access to the vendor's technician after verification of the Name & Mobile Number from the given vendor contact person. You are also requested to <strong>check and verify</strong> the physical equipment(s) Brand, Model, Serial etc and provide a written <strong>acknowledgement</strong> after successful installation.</p>
    
        <p>Your cooperation is highly appreciated.</p>
        <p>Ma-assalam,<br>With Best Regards,<br><br><strong>CCTV & UPS Management Department</strong><br>ATMMD, DBW, Head Office</p>
    </div>
    <div class="footer-box"><strong>ATM Management Division, DBW, HO</strong><br>75, Dilkusha C/A, Dhaka-1000, Bangladesh; email: group_atmmd@islamibankbd.com</div>
</div>
</body>
</html>
<?php exit; }

/* =========================================================
   DELETE LOGIC
========================================================= */
if (isset($_GET['delete_id'])) {
    $did = (int)$_GET['delete_id'];
    $conn->query("DELETE FROM cctv_set_requisition_items WHERE requisition_id = $did");
    $conn->query("DELETE FROM cctv_set_requisition_remarks WHERE set_requisition_id = $did");
    $conn->query("DELETE FROM cctv_set_requisition WHERE id = $did");
    header("Location: cctv_set_requisition_list.php?msg=deleted");
    exit;
}

/* =========================================================
   SAVE QUICK REMARK
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_quick_remark'])) {
    $rid = (int)$_POST['req_id'];
    $rem = trim($_POST['remark_text']);
    if ($rid > 0 && $rem !== '') {
        $uid = $_SESSION['user_id'] ?? null;
        $stmt = $conn->prepare("INSERT INTO cctv_set_requisition_remarks (set_requisition_id, remark, created_by, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("isi", $rid, $rem, $uid);
        $stmt->execute();
        header("Location: cctv_set_requisition_list.php?msg=remark_added");
        exit;
    }
}

/* =========================================================
   STATUS MAPPING
========================================================= */
$statusLabels = [
    'Waiting_for_Approval' => 'Waiting for approval',
    'Sent_to_CPD' => 'Sent to CPD',
    'Waiting_for_Technical_Evaluation' => 'Waiting for technical evaluation',
    'Waiting_for_Work_Order' => 'Waiting for work order',
    'Waiting_for_Delivery' => 'Waiting for delivery',
    'Waiting_for_QC' => 'Waiting for QC',
    'Technical_Evaluation_Passed' => 'Tech. Eva Passed',
    'Technical_Evaluation_Failed' => 'Tech. Eva Failed',
    'QC_Passed' => 'QC Passed',
    'QC_Failed' => 'QC Failed',
    'Waiting_for_Installation' => 'Waiting for Installation',
    'Installed' => 'Installed',
    'Closed' => 'Closed',
    'Cancelled' => 'Cancelled'
];

$msg = $_GET['msg'] ?? '';
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

/* =========================================================
   FETCH LIST DATA
========================================================= */
$sql = "
    SELECT 
        r.*, 
        v.vendor_name,
        l.atm_id, l.booth_name, l.branch_name, l.zone_name,
        (SELECT remark FROM cctv_set_requisition_remarks WHERE set_requisition_id = r.id ORDER BY id DESC LIMIT 1) AS latest_remark
    FROM cctv_set_requisition r
    LEFT JOIN cctv_locations l ON r.cctv_location_id = l.id
    LEFT JOIN cctv_vendors v ON r.selected_vendor_id = v.id
    WHERE 1=1
";

$params = []; $types = "";
if ($search !== '') {
    $sql .= " AND (l.atm_id LIKE ? OR l.booth_name LIKE ? OR l.branch_name LIKE ? OR r.requisition_no LIKE ?) ";
    $sterm = "%{$search}%";
    for ($i = 0; $i < 4; $i++) { $params[] = $sterm; $types .= "s"; }
}
if ($status_filter !== '') {
    $sql .= " AND r.status = ? ";
    $params[] = $status_filter; $types .= "s";
}
$sql .= " ORDER BY r.id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$res = $stmt->get_result();
$requisitions = $res->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CCTV Set Requisition List</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f7fa; margin: 0; padding: 20px; font-size: 12px; }
        .container { max-width: 100%; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .flex-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .btn { padding: 5px 10px; border-radius: 4px; cursor: pointer; text-decoration: none; color: #fff; font-size: 11px; font-weight: bold; border: none; display: inline-block; margin: 1px; }
        .btn-blue { background: #0d6efd; } .btn-success { background: #198754; } .btn-danger { background: #dc3545; } .btn-secondary { background: #6c757d; } .btn-info { background: #0dcaf0; color: #000; } .btn-warning { background: #ffc107; color: #000; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #dee2e6; padding: 8px; text-align: left; vertical-align: top; }
        th { background: #f8f9fa; white-space: nowrap; }
        .status-badge { padding: 3px 8px; border-radius: 10px; font-size: 10px; color: #fff; font-weight: bold; display: inline-block; white-space: nowrap; background: #6c757d; }
        .Installed, .QC_Passed { background: #198754; } 
        .Waiting_for_Approval, .Sent_to_CPD { background: #0d6efd; }
        .Cancelled, .QC_Failed, .Technical_Evaluation_Failed { background: #dc3545; }
        .Waiting_for_Work_Order, .Waiting_for_Delivery { background: #fd7e14; }
        .Waiting_for_Installation { background: #ffc107; color: #000; }
                .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
        .modal-content { background: #fff; margin: 5% auto; padding: 20px; border-radius: 8px; width: 600px; max-width: 90%; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .details-grid { display: grid; grid-template-columns: 160px 1fr; gap: 8px; border-top: 1px solid #eee; padding-top: 10px; }
        .details-grid div:nth-child(odd) { font-weight: bold; background: #f9f9f9; padding: 4px; }
    </style>
</head>
<body>
<?php include_once __DIR__ . '/includes/navbar.php'; ?>
<div class="container">
    <div class="flex-header">
        <h2 style="margin:0; color:#0d6efd;">CCTV Set Requisition List</h2>
        <div>
            <a href="cctv_set_requisition.php" class="btn btn-success">+ New Requisition</a>
            <button onclick="window.print()" class="btn btn-secondary">Print List</button>
            <a href="cctv_dashboard.php" class="btn btn-blue">Dashboard</a>
        </div>
    </div>

    <form method="GET" class="filter-section" style="margin-bottom:15px; display:flex; gap:10px;">
        <input type="text" name="search" placeholder="Search ATM/Branch..." value="<?= h($search) ?>" style="padding:6px; border:1px solid #ddd; border-radius:4px;">
        <select name="status" style="padding:6px; border:1px solid #ddd; border-radius:4px;">
            <option value="">All Statuses</option>
            <?php foreach($statusLabels as $k => $v): ?>
                <option value="<?=$k?>" <?=($status_filter==$k?'selected':'')?>><?=$v?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-blue">Filter</button>
    </form>

    <div style="overflow-x:auto;">
        <table>
            <thead>
                <tr>
                    <th>Serial</th>
                    <th>ATM ID</th>
                    <th>Location</th>
                    <th>Branch Contact</th>
                    <th>IP Details</th>
                    <th>Status</th>
                    <th>Vendor</th>
                    <th>Installation Date</th>
                    <th>Remarks</th>
                    <th class="action-col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($requisitions as $i => $r): 
                    $currStatus = $r['status'] ?? 'Waiting_for_Approval';
                    $displayStatus = $statusLabels[$currStatus] ?? str_replace('_', ' ', $currStatus);
                ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><strong><?= h($r['atm_id']) ?></strong></td>
                    <td><?= h($r['booth_name']) ?><br><small style="color:#666;"><?= h($r['branch_name']) ?></small></td>
                    <td><?= h($r['branch_contact'] ?: '-') ?></td>
                    <td style="font-size:11px; white-space:nowrap;">
                        <strong>IP:</strong> <?= h($r['internal_ip'] ?: '-') ?><br>
                        <strong>SM:</strong> <?= h($r['subnet_mask'] ?: '-') ?><br>
                        <strong>GW:</strong> <?= h($r['gateway'] ?: '-') ?>
                    </td>
                    <td><span class="status-badge <?= h($currStatus) ?>"><?= h($displayStatus) ?></span></td>
                    <td><?= h($r['vendor_name'] ?: '-') ?></td>
                    <td><?= ($r['installation_date'] && $r['installation_date']!='0000-00-00') ? date('d-M-Y', strtotime($r['installation_date'])) : '-' ?></td>
                    <td style="max-width:150px; font-size:11px;"><?= nl2br(h($r['latest_remark'] ?: $r['notes'])) ?></td>
                    <td class="action-col" style="white-space:nowrap;">
                        <?php if ($currStatus === 'Waiting_for_Installation'): ?>
                            <a href="cctv_set_requisition_list.php?view_branch_mail=1&id=<?= (int)$r['id'] ?>" target="_blank" class="btn btn-warning">Branch Mail</a>
                        <?php endif; ?>
                        <button class="btn btn-info" onclick='showDetails(<?= json_encode($r) ?>)'>Details</button>
                        <button class="btn btn-secondary" onclick="openRemarkModal(<?= $r['id'] ?>, '<?= h($r['atm_id']) ?>')">Remark</button>
                        <a href="cctv_set_requisition.php?id=<?= $r['id'] ?>" class="btn btn-blue">Edit</a>
                        <a href="cctv_set_requisition_list.php?delete_id=<?= $r['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete this record?')">Del</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="detailsModal" class="modal">
    <div class="modal-content">
        <h3 id="detTitle" style="margin-top:0; border-bottom:2px solid #eee; padding-bottom:10px;">Requisition Details</h3>
        <div id="detBody" class="details-grid"></div>
        <div style="margin-top:20px; text-align:right;"><button class="btn btn-secondary" onclick="closeModal('detailsModal')">Close</button></div>
    </div>
</div>

<div id="remarkModal" class="modal">
    <div class="modal-content" style="width:400px;">
        <h3 id="remTitle" style="margin-top:0;">Add Remark</h3>
        <form method="POST">
            <input type="hidden" name="req_id" id="rem_req_id">
            <textarea name="remark_text" style="width:100%; height:80px; padding:8px; border:1px solid #ddd; border-radius:4px;" placeholder="Update status/notes..." required></textarea>
            <div style="margin-top:15px; text-align:right;">
                <button type="submit" name="save_quick_remark" class="btn btn-blue">Save</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('remarkModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function showDetails(data) {
    document.getElementById('detTitle').innerText = "Details: " + (data.atm_id || data.requisition_no);
    let html = "";
    const map = {
        "Req. No": data.requisition_no, 
        "ATM ID": data.atm_id, 
        "Booth Name": data.booth_name,
        "Branch": data.branch_name, 
        "Zone": data.zone_name, 
        "Branch Contact": data.branch_contact || '-',
        "Internal IP": data.internal_ip || '-',
        "Subnet Mask": data.subnet_mask || '-',
        "Gateway": data.gateway || '-',
        "Status": data.status,
        "Vendor": data.vendor_name || 'Not assigned', 
        "Installation": data.installation_date,
        "Latest Remark": data.latest_remark || data.notes || '-'
    };
    for(let k in map) { html += `<div>${k}</div><div>${map[k] || '-'}</div>`; }
    document.getElementById('detBody').innerHTML = html;
    document.getElementById('detailsModal').style.display = 'block';
}
function openRemarkModal(id, atm) {
    document.getElementById('rem_req_id').value = id;
    document.getElementById('remTitle').innerText = "Add Remark for " + atm;
    document.getElementById('remarkModal').style.display = 'block';
}
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
window.onclick = function(event) { if (event.target.className === 'modal') { event.target.style.display = "none"; } }
</script>
</body>
</html>